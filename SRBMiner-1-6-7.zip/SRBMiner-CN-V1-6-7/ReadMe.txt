SRBMiner Cryptonight AMD GPU Miner V1.6.7
-----------------------------------------

Download:
http://www.srbminer.com/download.html
https://mega.nz/#F!qVIgxAwB!kKmgCDICmQwbdVvMb-tAag

BitcoinTalk thread:
https://bitcointalk.org/index.php?topic=3167363.0

If you are a beginner miner and need help in setting up SRBMiner, check out this link : http://www.srbminer.com/start.html
If you need help in setting up algo switching, check out this link : http://srbminer.com/algoswitching.html


SUPPORTED ALGOS:
----------------

- Cryptonight [normal]
- Cryptonight Lite [lite]
- Cryptonight V7 [normalv7]
- Cryptonight Lite V7 [litev7]
- Cryptonight Heavy [heavy]
- Cryptonight Haven [haven]
- Cryptonight Fast [fast]
- Cryptonight BitTube V2 [bittubev2]
- Cryptonight StelliteV4 [stellitev4]
- Cryptonight ArtoCash [artocash]
- Cryptonight Alloy [alloy]
- Cryptonight B2N [b2n]
- Cryptonight MarketCash [marketcash]
- Cryptonight Italo [italo]
- Cryptonight Red [mox]


Supports Nicehash & SSL/TLS encrypted connections


For best results use Adrenalin 18.6.1 or Adrenalin 18.3.4 drivers!


DevFee:
- Low DevFee (~0.85% normal mode, ~0.91% algo switching mode)
- Non-agressive DevFee mining -> if miner can't connect to DevFee pool, no problem, switching back to user pool ASAP


Extra:
- Watchdog that monitors your GPU threads, if they stop hashing for a few minutes, miner restarts itself
- Hash monitor, if 5 minute average hash falls under the value you define, miner restarts itself
- Set system shutdown temperature, to protect your GPU's from overheating
- Restart (disable/enable) Vega gpu's with before mining starts
- API for rig monitoring
- Set compute mode and disable crossfire on all AMD cards
- Benchmark every algo locally without connecting to a pool

 

--------------------------------------------------------------------------
CONFIG.TXT
--------------------------------------------------------------------------


You can use these options :
Note: use all lowercase characters

"cryptonight_type" : "normal, normalv7, lite, litev7, heavy, bittubev2, artocash, alloy, marketcash, b2n, stellitev4, haven, fast, italo, mox"
"intensity" : 0-300, if set to 0 miner will try to find best settings for every video card
"worksize" : 1-256, if set, every video card will use this worksize, if not set, using auto detected value
"double_threads" : true or false, set it to true for best performance
"giveup_limit" : number, how many times to try connecting to a pool before switching to next pool from pools.txt. If set to 0 miner will quit and won't retry connecting.
"timeout" : number - seconds, when is a connection to a pool treated as time out
"retry_time" : number - seconds, how much to wait before trying to reconnect to a pool
"reboot_script" : filename to a batch file in miner directory, if set it turns off built in miner reset procedure on gpu failure, and instead runs this script
"main_pool_reconnect" : number - seconds (minimum is 3 minutes or 180 sec), how often to try to reconnect back to the main pool. Default is 10 minutes.
"min_rig_speed" : number - in H/S, it defines the minimum rig hashing speed we want to maintain. If 5 minute average hashing speed is less than this, miner restarts.
"min_rig_speed_duration" : number - in seconds (minimum is 30 sec), defines the time period for average hashing speed calculation, used with 'min_rig_speed' parameter

"api_enabled" : true or false, if true we can connect to it on 127.0.0.1:21555
"api_rig_name" : identifier name for your rig
"api_port" : number, this is where API will be available (Default is 21555 if not set)

"target_temperature" : number between 0-99, miner will try to maintain this temperature on all found video cards (ADL must be enabled, works only on cards supporting OverdriveN)
"shutdown_temperature" : number between 0-100, if this temperature is reached, miner will shutdown system (ADL must be enabled)



=================================
Manual GPU setup (advanced)
=================================

To manually set up video cards, you must create a "gpu_conf" array in the config.txt file.

Example :

"gpu_conf" : 
[ 
	{ "id" : 0, "intensity" : 50, "worksize" : 4, "threads" : 1},
	{ "id" : 1, "intensity" : 45, "worksize" : 4, "threads" : 2},
	{ "id" : 2, "intensity" : 40, "worksize" : 8, "threads" : 3},
	{ "id" : 3, "intensity" : 55, "worksize" : 8, "threads" : 4}
]


Additional parameters: 

"kernel" : 0-2 , if not set, or set to 0, miner will select most suitable kernel (1-FOR GCN CARDS, 2-FOR PRE-GCN CARDS)
"target_temperature" : 0-99, if set miner will try to maintain this temperature for this particular video card. If option 'target_temperature' on top of config.txt is set, this option WILL BE IGNORED. (ADL must be enabled, works only on cards supporting OverdriveN)
"target_fan_speed" : 0-6000, if set miner will try to set the video card fan speed to this speed. Setting is in RPM (rounds per minute) (ADL must be enabled)
"adl_type" : 1 or 2 , 1 - USE OVERDRIVEN , 2 - USE OVERDRIVE 5. Default is 1 if not set. Option 2 (Overdrive 5) is suitable for older cards
"persistent_memory" : true or false, if set miner will try to allocate extra memory for the video card, if it is available. CAUTION, MINER CAN BECOME UNSTABLE AND CRASH if using this option




--------------------------------------------------------------------------
POOLS.TXT
--------------------------------------------------------------------------


Example:

{
"pools" :
[
	{"pool" : "pool_1_address", "wallet" : "pool_1_wallet", "password" : "x"},
	{"pool" : "pool_2_address", "wallet" : "pool_2_wallet", "password" : "x"},
	{"pool" : "pool_3_address", "wallet" : "pool_3_wallet", "password" : "x"}
]
}

Pool on first position is the MAIN pool, others are counted as FAILOVER pools.

Additional parameters:

"worker" : worker name, not every pool supports this
"nicehash" : true or false, set this to true if you are using Nicehash
"keepalive" : true or false, not every pool supports this
"pool_use_tls": true or false, if true miner will use SSL/TLS to connect to pool
"job_timeout" : number in seconds, if no job is received for this period, miner will reconnect to the pool (Default is 20 minutes)
"max_difficulty" : number, if pool difficulty is above this value miner will reconnect to the pool




--------------------------------------------------------------------------
START.BAT
--------------------------------------------------------------------------

There are some options that must be set in start.bat, and not within config.txt or pools.txt.

Parameters:

--config filename (use config file other than config.txt)
--pools filename (use pools file other than pools.txt)
--algos filename (use algos file other than algos.txt)
--logfile filename (enable logging to file)
--listdevices (list available devices)
--listdevicesreordered (list available devices ordered by busid)
--gpureorder (order devices by busid)
--adldisable (disable ADL)
--disablegpuwatchdog (disable gpu crash detection watchdog)
--resetfans (reset fans back to default settings on miner exit)
--enableduplicategpuid (allows usage of same gpu id multiple times in gpu_conf)
--setcomputemode (sets AMD gpu's to compute mode & disables crossfire - run as admin)
--runbenchmark (benchmark your current algo settings offline)
--benchmarkduration (how long to run the benchmark in seconds, max is 3 minutes, def. is 1 min.)
--resetvega (disable/enable Vega video cards before mining)
--startupscript filename(run custom batch script before mining)
--usealgoswitching (use miner in algo switching mode - pool must support it)
--usealgomapping value (type of algo mappings to use: 1-short, 2-long, def. is short)
--algoswitchmintime value (minimum time to mine using same algo, in seconds, min is 3 minutes, def. is 10 min. - pool must support it)


When setting any of the parameters under, don't use " or ' around the value!


To setup your video cards in cmd line :

These settings override the settings in config.txt
If you want to set everything in cmd line, you still need to have an empty config.txt file (which contains just : {}, or any other parameter like api etc etc )
First list devices (--listdevices or --listdevicesreordered if you are going to use --gpureorder), then you know the GPU id's and can set them up easy.

Parameters:

--ccryptonighttype value (algo to use)
--cgpuid value (gpu id, comma separated values, use --listdevices to see available)
--cgpuintensity value (gpu intensity, comma separated values)
--cgputhreads value (number of gpu threads, comma separated values)
--cgpuworksize value (gpu worksize, comma separated values)
--cgputargettemperature value (gpu temperature, comma separated values)
--cgputargetfanspeed value (gpu fan speed in RPM, comma separated values)
--cgpuadltype value (gpu adl to use (1 or 2), comma separated values)
--cgpukernel value (gpu kernel to use (1 or 2), comma separated values)



To setup your main pool in cmd line :

If set here, this will be the MAIN pool, you can also add more pools in pools.txt config file.

Parameters:

--cworker value (worker name or rig id - pool must support it)
--cpool url:port (pool address:port without stratum prefix)
--cwallet address (user wallet address)
--cpassword value (pool password)
--ctls value (use SSL/TLS, true or false)
--cnicehash value (force nicehash, true or false)


Ex. for GPU and POOL setup from CMD:

Use 1 GPU with id 0 , intensity 120, 2 threads on algo cryptonight v7 on nanopool:
SRBMiner-CN.exe --ccryptonighttype normalv7 --cgpuid 0 --cgpuintensity 120 --cgputhreads 2 --cpool xmr-eu1.nanopool.org:14444 --cwallet 4A5hJyu2FvuM2azexYssHW2odrNCNWVqLLmzCowrA57xGJLNufXfzVgcMpAy3YWpzZSAPALhVH4Ed7xo6RZYyw2bUtbm12g.donation


Use 5 GPUS with id 0,1,2,3,4 , intensities 56,56,55,58,55, 2 threads for each GPU, on algo cryptonight v7 on nanopool:
SRBMiner-CN.exe --ccryptonighttype normalv7 --cgpuid 0,1,2,3,4 --cgpuintensity 56,56,55,58,55 --cgputhreads 2,2,2,2,2 --cpool xmr-eu1.nanopool.org:14444 --cwallet 4A5hJyu2FvuM2azexYssHW2odrNCNWVqLLmzCowrA57xGJLNufXfzVgcMpAy3YWpzZSAPALhVH4Ed7xo6RZYyw2bUtbm12g.donation



--------------------------------------------------------------------------
ALGO SWITCHING MODE
--------------------------------------------------------------------------

To use the algo switching mode (--usealgoswitching parameter in .bat), the pool must support the XMRig Proxy Stratum protocol extensions(https://github.com/xmrig/xmrig-proxy/blob/master/doc/STRATUM_EXT.md)
SRBMiner is even ahead and using the algo-perf parameter (https://github.com/xmrig/xmrig/issues/618) that was suggested by Monero Ocean but still not implemented in XMRig Proxy.

How does this work?

The pool always sends you a job for the algo that is most profitable to mine with your rig at that moment.
It is simple as that.


How to set it up ?

There is a file with name algos.txt, where every algo that SRBMiner supports is filled.
You need to edit the 'hashrate' value in every algo, and 'startup_script' if you are going to use it.
Also if you want, you can fully customize configs for every algo. You can find them in the 'Config' folder.

Short explanation of parameters in algos.txt:

The parameter "config" expects a filename to a config file where you set up everything for a specific algo (config-normalv7.txt is for CNV7 as you can guess).
So on every new algo switch SRBMiner will initialize settings specific for that algo.

"pools" is a config file for pools, where you can define multiple pools with algo switching ability, so you have failovers too.

"hashrate" is a parameter where you should write the total hashrate of your rig (in H/S) for that specific algo (you can easily find it out by running a benchmark for example).
This field is used by the pool in calculating what is the most profitable algo for you to mine.

"startup_script" can be used to run a script (batch file) before miner starts. You can for example set clocks, voltages, etc. specific to that algo


There is also a file with name pools-algoswitch.txt where i predefined a few pools on Monero Ocean (the only algo switching pool at the moment), where you need to change the wallet address to your own.

Now that you have algos.txt and pools-algoswitch.txt set up, start the miner by running start-algo-switching.bat


It is VERY IMPORTANT to use config files here, and not set GPU's and pool in command line. If you do so, algo switching probably won't work.


TIP:
To always get the maximum hashrate from your Vega's, use the --resetvega parameter , so on every algo change you disable/enable your cards before mining.
Example :

SRBMiner-CN.exe --config Config\config-normalv7.txt --pools pools-algoswitch.txt --logfile log-algo-switching.txt --usealgoswitching --resetvega



--------------------------------------------------------------------------
KEYBOARD SHORTCUTS
--------------------------------------------------------------------------


- Press 's' to see some basic stats
- Press 'h' to see hashing speed
- Press 'p' to fast switch to next pool from pools config file
- Press 'r' to reload pools, if you add a pool to pools config, no need to restart miner to use new pool
- Press number from 0-9 to disable/enable from gpu0-gpu9, then shift+0 for gpu10, shift+1 for gpu11..etc. until gpu19 max (use US keyboard where SHIFT+1 = !, SHIFT+2 = @ ..etc..)



--------------------------------------------------------------------------
INFORMATION
--------------------------------------------------------------------------

You have to change the wallet address in sample config.txt file to your own, or you will donate some hashing power to me. (Thanks)
SRBMiner is using a heavily modified version of Wolf0/Wolf9466/OhGodAPet's OpenCL kernel.